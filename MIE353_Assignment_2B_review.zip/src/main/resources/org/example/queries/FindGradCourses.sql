SELECT courseID, courseName
FROM course
WHERE gradCourse >= 1;